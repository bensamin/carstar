	$(document).ready(function(){
		//载入头部
		$(".header").load("nav.html");
		//载入底部
		$(".footer").load("footer.html");
		//订单
		$(".add-order1").load("order.html");
		//产品参数
		$(".add-parameters").load("parameters.html");
		//添加 类名
	});    

